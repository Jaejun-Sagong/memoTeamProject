package com.sparta.memoproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JwtTutorialApplicationTests {

	@Test
	void contextLoads() {
	}

}
