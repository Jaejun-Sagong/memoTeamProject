package com.sparta.memoproject.model;

public enum Authority {
    ROLE_USER, ROLE_ADMIN
}
